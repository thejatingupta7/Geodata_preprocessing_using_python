---------------------------------------------------------------------------------
SHPFILE READER SOURCE CODE

The source code for reading the map shapefiles is included in this directory.
It can be compiled to the file SHPreader.swf, which is read by StatPlanet.

The code was written by Edwin van Rijkom under the LGPL license, with some additions by Andy Woodruff, 
and some slight modifications for use in StatPlanet.

If you wish to change the names of the map files being read, you can change this in SHPreader.as, 
and publish it as SHPreader.swf through the file SHPreader.fla.

For more information, see: http://shp.riaforge.org/

---------------------------------------------------------------------------------
